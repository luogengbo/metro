module.exports = {
    ResizeSensor: require('./src/ResizeSensor'),
    ElementQueries: require('./src/ElementQueries')
};
