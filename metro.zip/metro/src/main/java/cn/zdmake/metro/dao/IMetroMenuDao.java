package cn.zdmake.metro.dao;

import cn.zdmake.metro.base.dao.BaseDao;
import cn.zdmake.metro.model.MetroSysMenu;
/**
 * 菜单数据处理接口
 * @author MAJL
 *
 */
public interface IMetroMenuDao extends BaseDao<MetroSysMenu> {

}
