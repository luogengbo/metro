package cn.zdmake.metro.base.utils;

public class ZookeTransactionException extends RuntimeException implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -5133748034860026946L;

	public ZookeTransactionException(String msg){
		super(msg);
	}
}
