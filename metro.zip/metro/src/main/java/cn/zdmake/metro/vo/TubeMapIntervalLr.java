package cn.zdmake.metro.vo;

public class TubeMapIntervalLr implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -1681145059013999648L;
	
	private DataChild left;
	private DataChild right;
	public DataChild getLeft() {
		return left;
	}
	public void setLeft(DataChild left) {
		this.left = left;
	}
	public DataChild getRight() {
		return right;
	}
	public void setRight(DataChild right) {
		this.right = right;
	}

	

}
