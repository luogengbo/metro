package cn.zdmake.metro.service;

/**
 * 地铁线路区间沉降点监测数据业务接口
 * @author luowq
 *
 */
public interface IMetroLineIntervalMdService {

}
