package cn.zdmake.metro.vo;

import java.util.Map;

public class IhistorianResponse {
	private int code;
	private String message;
	private Map<String, Object> result;
	
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Map<String, Object> getResult() {
		return result;
	}
	public void setResult(Map<String, Object> result) {
		this.result = result;
	}

}
